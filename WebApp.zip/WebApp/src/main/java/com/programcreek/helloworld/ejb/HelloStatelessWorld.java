package com.programcreek.helloworld.ejb;

import javax.ejb.Remote;

@Remote
public interface HelloStatelessWorld {
	public String getHelloWorld(String name);
}
