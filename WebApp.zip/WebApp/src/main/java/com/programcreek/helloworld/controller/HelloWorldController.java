package com.programcreek.helloworld.controller;

import javax.ejb.EJB;
import javax.ejb.Stateless;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.programcreek.helloworld.ejb.HelloStatelessWorld;

@Controller
@Stateless
public class HelloWorldController {
	
	@EJB(beanName="HelloStatelessWorld")
	public HelloStatelessWorld helloStatelessWorld;

	String message = "Welcome to Spring MVC!";

	@RequestMapping("/hello")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) {
		System.out.println("in controller");
		String personName = helloStatelessWorld.getHelloWorld(name);
		ModelAndView mv = new ModelAndView("helloworld");
		mv.addObject("message", message);
		mv.addObject("name", personName);
		return mv;
	}

}
