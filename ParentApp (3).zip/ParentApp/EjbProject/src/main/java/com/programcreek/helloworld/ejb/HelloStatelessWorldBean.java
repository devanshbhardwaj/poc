package com.programcreek.helloworld.ejb;

import javax.ejb.Stateless;

import org.springframework.stereotype.Component;

/**
 * Session Bean implementation class HelloStatelessWorld
 */
@Stateless
public class HelloStatelessWorldBean implements HelloStatelessWorld {

	public String getHelloWorld(String name) {
		return name + " entered in Stateless world!";
	}

}
