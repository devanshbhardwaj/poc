package com.programcreek.helloworld.ejb;

import javax.ejb.Local;

@Local
public interface HelloStatelessWorld {
	public String getHelloWorld(String name);
}
