package com.programcreek.helloworld.controller;

import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.programcreek.helloworld.ejb.HelloStatelessWorld;
import com.programcreek.helloworld.ejb.HelloStatelessWorldBean;

@Controller
public class HelloWorldController {
	//@EJB
	//private HelloStatelessWorld helloStatelessWorld;

	String message = "Welcome to Spring MVC!";

	@RequestMapping("/hello")
	public ModelAndView showMessage(
			@RequestParam(value = "name", required = false, defaultValue = "World") String name) throws NamingException {
		HelloStatelessWorld helloStatelessWorld = new HelloStatelessWorldBean();
		String personName = helloStatelessWorld.getHelloWorld(name);
		ModelAndView mv = new ModelAndView("helloworld");
		mv.addObject("message", message);
		mv.addObject("name", personName);
		return mv;
	}

}
